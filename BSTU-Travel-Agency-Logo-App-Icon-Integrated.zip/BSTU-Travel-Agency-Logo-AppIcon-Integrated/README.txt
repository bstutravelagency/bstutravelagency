BSTU Travel Agency website - Logo and app icon integrated

Included:
- index.html with BSTU logo in header and footer
- favicon sizes 32x32 and 64x64
- Apple touch icon
- 192x192 and 512x512 app icons
- site.webmanifest for installable app/PWA icon metadata
- complete assets folder

IMPORTANT: Upload index.html, site.webmanifest, and the entire assets folder together into the same website root folder (for example public_html). Do not upload only index.html.
